package javaPackage;

import java.util.Objects;

public class Book {

	private String title;
	private double[] ratingsArray = new double[3];

	public Book(String title, double[] ratingsArray) {
		super();
		this.title = title;
		this.ratingsArray = ratingsArray;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double[] getRatingsArray() {
		return ratingsArray;
	}

	public void setRatingArray(double[] ratingsArray) {
		this.ratingsArray = ratingsArray;
	}

	public double ratingAvreage() {

		double sumOfRatings = 0;
		for (double rate : ratingsArray) {
			sumOfRatings += rate;
		}

		return sumOfRatings / ratingsArray.length;

	}

	public double ratingAvreage(boolean want) {
		if (want) {
			double sumOfRatings = 0;
			for (double rate : ratingsArray) {
				sumOfRatings += rate;
			}
			return sumOfRatings / ratingsArray.length;
		}else {return 0;}
	}

	@Override
	public int hashCode() {
		return Objects.hash(title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		return Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "Book [title=" + title + "]";
	}

}
