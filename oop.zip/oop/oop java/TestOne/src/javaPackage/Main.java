package javaPackage;
import java.util.ArrayList;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		ArrayList<Book> booksList = new ArrayList<Book>() ;
		Scanner taking = new Scanner(System.in) ; 
		Library lib = new Library("Ajyad", booksList);
		
		int totalLaps = 0 ;
		System.out.println("how many books you want to add ?");
		totalLaps = taking.nextInt() ;
		for (int lap = 0 ; lap < totalLaps; lap++) {
			System.out.println("Please enter the title of book " + (lap+1));
			taking.nextLine();
			String title = taking.nextLine();
			System.out.println("Enter 3 ratings for the book " + title );
			double[] ratingsArray = new double[3];
			for(int i = 0 ; i <3 ; i++) {
				double rate  = taking.nextDouble();
				ratingsArray[i] = rate ;
			}
			Book book = new Book(title, ratingsArray);
			lib.AddABook(book);
		}
		for(Book book : booksList ) {
			System.out.println("Book: " + book.getTitle() + "has an avrage rate of, " + book.ratingAvreage());
			
		}
		
		lib.PrintTheList();
		System.out.println("what is the name of the book you want to look for");
		taking.nextLine();  // Consume the leftover newline
		String title = taking.nextLine();  // Read the full line
		lib.searchBook(title);
		lib.removeBook(title);
		lib.highestAve(title);
		taking.close() ;
		
		
	}
}
