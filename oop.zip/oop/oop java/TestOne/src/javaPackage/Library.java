package javaPackage;

import java.util.ArrayList;

public class Library {

	private String name;
	private ArrayList<Book> booksArray = new ArrayList<Book>();;

	public Library(String name, ArrayList<Book> booksArray) {
		super();
		this.name = name;
		this.booksArray = booksArray;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<Book> getBooksArray() {
		return booksArray;
	}

	public void setBooksArray(ArrayList<Book> booksArray) {
		this.booksArray = booksArray;
	}

	public void AddABook(Book book) {

		if (booksArray.contains(book)) {
			System.out.println("we have this before");
		} else {
			booksArray.add(book);
			System.out.println(book.getTitle() + " has been added to the " + name + "'s" + "library");
		}
	}

	public void PrintTheList() {
		System.out.println(booksArray);
	}

	public void searchBook(String name) {
		boolean found = false;
		for (Book book : booksArray) {
			if (book.getTitle().trim().equals(name.trim())) {
				System.out.println(name + " was found and it's average rate is " + book.ratingAvreage());
				found = true;
				return;
			}
		}
		if (!found) {
			System.out.println("we didn't find this");
		}
	}

	public void removeBook(String name) {
		for (int i = 0; i < booksArray.size(); i++) {
			if (booksArray.get(i).getTitle().equals(name)) {
				booksArray.remove(i);
				System.out.println(name + " removed successfully");
				return; // Exit after removing to avoid IndexOutOfBoundsException
			}
		}
		System.out.println("we didn't find this to remove it");
	}

	public void highestAve(String name) {
		double ave = 0;
		String ti = "";
		for (Book book : booksArray) {
			if (book.ratingAvreage() > ave) {
				ave = book.ratingAvreage();
				ti = book.getTitle();
			}
		}
		System.out.println("Highest-rated book: " + ti + ", the average rating equals" + ave);
	}

}
