from Book import Book  
from Library import Library  
def main():
    books_list = []
    lib = Library("Ajyad", books_list) # Call the Class

    total_laps = int(input("How many books do you want to add? "))

    for lap in range(total_laps):
        title = input(f"Please enter the title of book {lap + 1}: ")
        print(f"Enter 3 ratings for the book {title}: ")
        ratings_array = []
        for _ in range(3):
            while True:
                try:
                    rating = float(input("Enter rating: "))
                    if 0 <= rating <= 5:
                        ratings_array.append(rating)
                        break
                    else:
                        print("Invalid rating. Please enter a number between 0 and 5")
                except ValueError:
                    print("Invalid input.  Please enter a number.")

        book = Book(title, ratings_array)  # Call the Class
        lib.add_a_book(book)

    lib.Print_the_list()

    search_title = input("What is the name of the book you want to look for? ")
    lib.search_book(search_title)

    remove_title = input("Enter the title of the book you want to remove: ")
    lib.remove_book(remove_title)

    lib.highest_ave()

if __name__ == "__main__":
    main()