class Book:
    def __init__(self, title, ratingsArray):
        self._title = title
        self._ratingsArray = ratingsArray

    @property
    def title(self):
        return self._title

    @title.setter
    def title(self, value):
        self._title = value
        
    @property
    def ratings_array(self):
        return self._ratingsArray

    @ratings_array.setter
    def ratings_array(self, value):
        self._ratingsArray = value

    def rating_average(self):
        if not self._ratingsArray: 
            return None
        return sum(self._ratingsArray) / len(self._ratingsArray)

    # بعيد كتابة الهاش و الايكول مشان تشتغل المقارنة او على الاقل هيك لازم بجافا
    def __hash__(self):
        return hash(self._title)

    def __eq__(self, other):
        if isinstance(other, Book):
            return self._title == other._title
        return False

    def __str__(self):
        return f"Book [title={self._title}]"
    
    def __repr__(self):
        return f"Book(title='{self._title}', ratingsArray={self._ratingsArray})"
