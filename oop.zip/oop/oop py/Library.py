class Library:
    def __init__(self, name, booksArray):
        self._name = name
        self._booksArray = booksArray
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value

    @property
    def books_array(self):
        return self._booksArray

    @books_array.setter
    def books_array(self, value):
        self._booksArray = value

    def add_a_book(self, book):
        if book in self.books_array:
            print("We have this before")
        else:
            self.books_array.append(book)
            print(f"{book.title} has been added to {self._name}'s library")

    def Print_the_list(self):
        print(self.books_array)

    def search_book(self, name):
        found = False
        for book in self.books_array:
            if book.title == name :
                print(f"{name} was found and it's average rate is {book.rating_average()}")
                found = True
                return
        if not found :
            print("we didn't find this")

    def remove_book(self, name):
        for i, book in enumerate(self.books_array):  
            if book.title == name: 
                self.books_array.pop(i) 
                print(f"{name} removed successfully")
                return
        print("We didn't find this book to remove it.")

    def highest_ave(self):
        ave = 0 
        ti = ""
        for book in self.books_array :
            if book.rating_average() > ave :
                ave = book.rating_average()
                ti = book.title
        print(f"Highest-rated book: {ti}, the average rating equals {ave}")

